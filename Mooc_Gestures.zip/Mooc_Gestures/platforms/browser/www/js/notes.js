var app = {
	// Application Constructor, al arrancar la aplicacion 
	
	//este model contiene los datos json que vamos a utilizar en nuestros datos. Tiene dos notas
	model: {
		"notas": [{"titulo": "Comprar pan", "contenido": "Oferta en la panaderia de la esquina"}]
	},
	//inicializa funciones
	inicio: function(){
		this.iniciaFastClick();
		this.iniciaBotones();
		this.refrescarLista();
	},
	//para el click
	iniciaFastClick: function() {
		FastClick.attach(document.body);
	},
	//dos botones para anadir y salvar
	iniciaBotones: function() {
		var salvar = document.querySelector('#salvar');//boton salvar
		var anadir = document.querySelector('#anadir');//boton anadir
		//el boton anadir nos muestra el editor
		anadir.addEventListener('click' ,this.mostrarEditor, false);
		salvar.addEventListener('click' ,this.salvarNota, false);
	},
	//hace que cuando anadir nos muestra el titulo y la opcion salvar y los elementos que estan vacios
	mostrarEditor: function() {
		document.getElementById('titulo').value = "";
		document.getElementById('comentario').value = "";
		document.getElementById("notes-editor").style.display = "block";
		document.getElementById('titulo').focus();
	},
	//cuando salvamos,salvar, llamamos a estas funciones, construimos nota,etc
	salvarNota: function() {
		app.construirNota();
		app.ocultarEditor();
		app.refrescarLista();
		app.grabarDatos();//esto es para grabar los datos y que haya persistencia
	},
	
	//construimos y anadimos a nuestro modelo con el formato que queremos
	construirNota: function() {
		var notas = app.model.notas;
		notas.push({"titulo": app.extraerTitulo() , "contenido": app.extraerComentario() });
	},
	
	//ir al contenedor y dibujar todas las notas que tenemos en nuestro modelo de datos
	refrescarLista: function() {
		var div=document.getElementById('notes-list');
		div.innerHTML = this.anadirNotasALista();
	},

	anadirNotasALista: function() {
		var notas = this.model.notas;
		var notasDivs = '';
		for (var i in notas) {
			var titulo = notas[i].titulo;
			notasDivs = notasDivs + this.anadirNota(i, titulo);
		}
		return notasDivs;
	},

	anadirNota: function(id, titulo) {
		return "<div class='notes-item' id='notas[" + id + "]'>" + titulo + "</div>";
	},
	
	
	/************parte nueva ************/
	//esto es para grabar los datos y que haya persistencia, o lo que es lo mismo, que cuando cerremos la aplicacion y la volvamos a abrir, las notas que hayamos creado sigan alli
	//solicitamos a cordova que nos de un storage
	grabarDatos: function() {
		window.resolveLocalFileSystemURL(cordova.file.externalApplicationStorageDirectory, this.goFS, this.fail);
    },
	//en callback pedir el fichero en el que estamos
	goFS: function(fileSystem) {
		fileSystem.getFile("files/"+"model.json", {create:true, exclusive: false}, app.gotFileEntry, app.fail);
	},

	gotFileEntry: function(fileEntry) {
		fileEntry.createWriter(app.gotFileWriter, app.fail);
	},
	//cuando tenemos nuestro fichero abierto pedimos que grabe una version string de JSON de nuestro modelo. Con esto ya tendriamos todas nuestras notas grabadas en el sistema
	gotFileWriter: function(writer) {
		writer.onwriterend = function(evt) {
		console.log("datos grabados en externalApplicationStorageDirectory");
		};
		writer.write(JSON.stringify(app.model));//cuando esto este hecho, writer nos avisa de que esto ya esta terminado
	},

	leerDatos: function() {
		window.resolveLocalFileSystemURL(cordova.file.externalApplicationStorageDirectory, app.obtenerFS, app.fail);
	},

	obtenerFS: function(fileSystem) {
		fileSystem.getFile("files/"+"model.json", null, app.obtenerFileEntry, app.fail);
	},

	obtenerFileEntry: function(fileEntry) {
		fileEntry.file(app.leerFile, app.fail);
	},
	//tenemos un reader que lee el fichero que tenemos dispuuesto como texto, lo escribimos en su valor, lo pasamos a nuestro modelo
	leerFile: function(file) {
		var reader = new FileReader();
		reader.onloadend = function(evt) {
			var data = evt.target.result;
			app.model = JSON.parse(data);
			app.inicio();
		};
		reader.readAsText(file);
	},

	fail: function(error) {
		console.log(error.code);
		app.grabarDatos();
		setTimeout(app.leerDatos, 2500);
	},
	

	/******************************************/

	extraerTitulo: function() {
		return document.getElementById('titulo').value;
	},

	extraerComentario: function() {
		return document.getElementById('comentario').value;
	},
	//oculatamos editor que es aplicar un estilo
	ocultarEditor: function() {
		document.getElementById("notes-editor").style.display = "none";
	},
};
//app.inicio();//llamamos al inicio
//DomContentLoADED CARGADO EL CONTENIDO DEL DOM (QUE EL CSS Y HTML ESTEN CARGADOS)
//en esta linea nos aseguramos que exista un addEventListener
if('addEventListener' in document){
	  document.addEventListener('DOMContentLoaded', function() {
		    app.inicio();
	}, false);
};